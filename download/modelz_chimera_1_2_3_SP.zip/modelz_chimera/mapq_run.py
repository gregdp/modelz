
import modelz
import modelz.modelz

import os
dir_path = os.path.dirname(os.path.realpath(__file__))

#print "Running calc..."
#print " - ", dir_path

modelz.modelz.Calc_( "" )
#Segger.mapq.CalcR_ ( sys.argv[-1] )
#Segger.mapq.CalcR_ ()
