# modelz

To Install:

1. Please note that UCSF Chimera is required to use ModelZ
2. Download latest version of ModelZ file from the download folder
3. In a terminal, navigate to where the file was downloaded
4. unzip modelz_*.zip
5. python install.py <path to Chimera>


